package com.example.saudeja12300454

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets



        }

        val btnCadastrar = findViewById<Button>(R.id.btn_cadastrar)

        val edtText = findViewById<EditText>(R.id.edt_text)

        val estoqueMedicamentos = mapOf(
            "Paracetamol" to true,
            "Ibuprofeno" to true,
            "Amoxicilina" to true,
            "Dipirona" to true,
            "Azitromicina" to false,
            "Aspirina" to false

        )

        btnCadastrar.setOnClickListener{

        val resposta = edtText.toString()

            if(estoqueMedicamentos[resposta] == true)
            {
                val txtResposta = findViewById<TextView>(R.id.txt_resposta)

                txtResposta.setText("Tem o remedio")


            } else if (estoqueMedicamentos[resposta] == false){
                val txtResposta = findViewById<TextView>(R.id.txt_resposta)

                txtResposta.setText("Não tem o remedio")
            }

        }

    }


}






